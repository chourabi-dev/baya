enum WeekDay { short, long }
enum SelectedDayPosition { left, right, center }
enum FullCalendarScroll { horizontal, vertical }
