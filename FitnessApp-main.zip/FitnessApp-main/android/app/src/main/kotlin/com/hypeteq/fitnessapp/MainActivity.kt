package com.hypeteq.fitnessapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
