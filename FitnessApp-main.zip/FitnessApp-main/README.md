# fitnessapp
 
Fitness workout app is a professional app template that provides pre-set workout plans for
bodybuilding, Weight Gain, Weight loss & other Fitness Workout as your bodybuilding and Workout trainer.

**Features**:

- Material mobile UI/UX design.
- Beautiful Pie, Line, Progress chart.
- Workout tracker, Workout schedule.
- Exercises details with steps UI.
- Progress photo gallery UI.
- Profile screen UI.
- Notification screen UI.
- Custom widgets, clean code.

![Preview](fitness_app.png)
